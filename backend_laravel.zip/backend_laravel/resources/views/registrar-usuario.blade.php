@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <main class="container">
                <h1>Crear cuenta</h1>
                <p class="subtitle">Regístrate para acceder a SocialFood Badajoz</p>

                @if($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('register') }}">
                    @csrf
                    
                    <div class="form-group">
                        <label for="nombre">Nombre completo</label>
                        <input id="nombre" 
                               name="nombre" 
                               type="text" 
                               value="{{ old('nombre') }}"
                               required 
                               autocomplete="name">
                        @error('nombre')
                            <small class="error text-danger" role="alert">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="container">
                        <h2>Selecciona tu rol</h2>

                        <div class="form-group">
                            <label for="rol">Tipo de usuario</label>
                            <select id="rol" 
                                    name="tipo_usuario" 
                                    aria-label="Selecciona tipo de usuario"
                                    required>
                                <option value="">Selecciona una opción…</option>
                                <option value="comercio" {{ old('tipo_usuario') == 'comercio' ? 'selected' : '' }}>Comercio</option>
                                <option value="voluntario" {{ old('tipo_usuario') == 'voluntario' ? 'selected' : '' }}>Voluntario</option>
                            </select>
                            @error('tipo_usuario')
                                <div class="error text-danger" role="alert">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email">Correo electrónico</label>
                        <input id="email" 
                               name="email" 
                               type="email" 
                               value="{{ old('email') }}"
                               required 
                               autocomplete="email">
                        @error('email')
                            <small class="error text-danger" role="alert">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input id="telefono" 
                               name="telefono" 
                               type="tel" 
                               value="{{ old('telefono') }}"
                               required 
                               placeholder="Ej: 600123456">
                        @error('telefono')
                            <small class="error text-danger" role="alert">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group password-group">
                        <label for="password">Contraseña</label>
                        <input id="password" 
                               name="password" 
                               type="password" 
                               required 
                               autocomplete="new-password">
                        @error('password')
                            <small class="error text-danger" role="alert">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group password-group">
                        <label for="password_confirmation">Confirmar contraseña</label>
                        <input id="password_confirmation" 
                               name="password_confirmation" 
                               type="password" 
                               required 
                               autocomplete="new-password">
                    </div>

                    <button type="submit" class="btn-primario">Crear cuenta</button>

                    <p class="small">
                        ¿Ya tienes cuenta?
                        <a href="{{ route('login') }}">Iniciar sesión</a>
                    </p>

                </form>
            </main>

        </div>
    </div>
</div>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/registrar_usuario.css') }}">
@endsection

@section('js')
    <script src="{{ asset('js/registrar-usuario.js') }}" defer></script>
@endsection

