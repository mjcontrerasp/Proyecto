<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comercio;

class ComercioController extends Controller
{
    public function registrar(Request $request)
    {
        $data = $request->validate([
            'id_usuario'        => 'required|integer|exists:usuarios,id_usuario',
            'nombre_comercial'  => 'required|string|max:255',
            'direccion'         => 'nullable|string|max:255',
            'horario'           => 'nullable|string|max:255',
            'activo'            => 'boolean'
        ]);

        $comercio = Comercio::create([
            'id_usuario'       => $data['id_usuario'],
            'nombre_comercial' => $data['nombre_comercial'],
            'direccion'        => $data['direccion'] ?? null,
            'horario'          => $data['horario'] ?? null,
            'activo'           => $data['activo'] ?? true,
        ]);

        return response()->json([
            'ok' => true,
            'id_comercio' => $comercio->id_comercio
        ]);
    }
}
