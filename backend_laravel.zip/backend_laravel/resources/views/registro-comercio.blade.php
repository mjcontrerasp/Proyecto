@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <main class="container">
                <h1>Completa los datos del comercio</h1>

                @if($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form method="POST" action="{{ route('comercio.store') }}">
                    @csrf

                    <div class="form-group">
                        <label for="nombre_comercial">Nombre comercial</label>
                        <input type="text" 
                               id="nombre_comercial" 
                               name="nombre_comercial" 
                               value="{{ old('nombre_comercial') }}"
                               required>
                        @error('nombre_comercial')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="direccion">Dirección</label>
                        <input type="text" 
                               id="direccion" 
                               name="direccion"
                               value="{{ old('direccion') }}">
                        @error('direccion')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="horario">Horario</label>
                        <input type="text" 
                               id="horario" 
                               name="horario"
                               value="{{ old('horario') }}">
                        @error('horario')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group checkbox-label">
                        <input type="checkbox" 
                               id="activo" 
                               name="activo" 
                               value="1"
                               {{ old('activo', true) ? 'checked' : '' }}>
                        <label for="activo">Activo</label>
                    </div>

                    <button type="submit">Registrar Comercio</button>
                </form>
            </main>

        </div>
    </div>
</div>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/comercio.css') }}">
@endsection

@section('js')
    <script src="{{ asset('js/registrar-comercio.js') }}" defer></script>
@endsection
