<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/login', function () {
    return view('index'); // index.blade.php
})->name('login');

Route::post('/login', [AuthController::class, 'login']);
use App\Http\Controllers\RegistroController;

Route::get('/register', function () {
    return view('registrar-usuario');
})->name('register');

Route::post('/register', [RegistroController::class, 'registrar']);

// RECUPERAR CONTRASEÑA
Route::get('/recuperar', function () {
    return view('recuperar-contrasena');
})->name('password.request');

Route::post('/recuperar', [AuthController::class, 'recuperarPassword'])
    ->name('password.recuperar');