<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario;
use Illuminate\Support\Facades\Hash;

class RegistroController extends Controller
{
    public function registrar(Request $request)
    {
        $data = $request->validate([
            'nombre'   => 'required|string|max:100',
            'email'    => 'required|email|unique:usuarios,email',
            'telefono' => 'nullable|string|max:20',
            'password' => 'required|string|min:6',
            'rol'      => 'required|in:comercio,voluntario'
        ]);

        $usuario = Usuario::create([
            'nombre'           => $data['nombre'],
            'email'            => $data['email'],
            'telefono'         => $data['telefono'] ?? null,
            'contrasena_hash'  => Hash::make($data['password']),
            'rol'              => $data['rol']
        ]);

        return response("OK:{$usuario->rol}:{$usuario->id_usuario}");
    }
}
