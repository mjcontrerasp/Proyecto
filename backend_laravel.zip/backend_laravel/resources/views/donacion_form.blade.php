@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="login-container">
                <h1>Donación de Comida</h1>
                <p class="subtitle">Completa los datos para publicar o editar tu donación</p>

                @if($errors->any())
                    <div class="alert alert-danger mt-3">
                        <ul>
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form class="login-form" method="POST" action="{{ isset($donacion) ? route('donaciones.update', $donacion->id) : route('donaciones.store') }}">
                    @csrf
                    @if(isset($donacion))
                        @method('PUT')
                    @endif

                    <div class="form-group">
                        <label for="tipo_comida">Tipo de Comida</label>
                        <input type="text" 
                               id="tipo_comida" 
                               name="tipo_comida" 
                               placeholder="Ej: Pan, Fruta, Verduras" 
                               value="{{ old('tipo_comida', $donacion->tipo_comida ?? '') }}"
                               required>
                        @error('tipo_comida')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="cantidad">Cantidad disponible</label>
                        <input type="number" 
                               id="cantidad" 
                               name="cantidad" 
                               placeholder="Cantidad en unidades o kilos" 
                               value="{{ old('cantidad', $donacion->cantidad ?? '') }}"
                               required>
                        @error('cantidad')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="fecha_hora">Fecha y Hora límite de recogida</label>
                        <input type="datetime-local" 
                               id="fecha_hora" 
                               name="fecha_hora" 
                               value="{{ old('fecha_hora', $donacion->fecha_hora ?? '') }}"
                               required>
                        @error('fecha_hora')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="punto_recogida">Punto de Recogida</label>
                        <input type="text" 
                               id="punto_recogida" 
                               name="punto_recogida" 
                               placeholder="Dirección o ubicación" 
                               value="{{ old('punto_recogida', $donacion->punto_recogida ?? '') }}"
                               required>
                        @error('punto_recogida')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <button type="submit">{{ isset($donacion) ? 'Actualizar Donación' : 'Guardar Donación' }}</button>
                </form>

                <div class="divider"></div>
                <a href="{{ route('donaciones.index') }}" class="register-link">Volver a mis donaciones</a>
            </div>

        </div>
    </div>
</div>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/donacion_form.css') }}">
@endsection
