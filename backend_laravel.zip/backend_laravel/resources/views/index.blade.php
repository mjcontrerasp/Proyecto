@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            
            <main class="login-container">
                <h1>SocialFood</h1>
                <p class="subtitle">Inicia sesión con tu cuenta</p>

                @if(session('error'))
                    <div class="alert alert-danger">
                        {{ session('error') }}
                    </div>
                @endif

                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                <form method="POST" action="{{ route('login') }}" class="login-form">
                    @csrf

                    <div class="form-group">
                        <label for="email">Correo electrónico</label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               placeholder="correo@ejemplo.com" 
                               value="{{ old('email') }}"
                               required>
                        @error('email')
                            <span class="error text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <div class="password-wrapper">
                            <input type="password" 
                                   id="password" 
                                   name="password" 
                                   placeholder="********" 
                                   required>
                            <button type="button" id="togglePassword" aria-label="Mostrar contraseña"></button>
                        </div>
                        @error('password')
                            <span class="error text-danger" role="alert">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group checkbox">
                        <input type="checkbox" id="remember" name="remember">
                        <label for="remember">Recordarme</label>
                    </div>

                    <button type="submit">Iniciar sesión</button>
                </form>

                <p class="register-link">¿No tienes cuenta? <a href="{{ route('register') }}">Registrarse</a></p>
                <p class="register-link">¿No recuerdas cual es tu cuenta? <a href="{{ route('password.request') }}">Recuperar</a></p>
            </main>

        </div>
    </div>
</div>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ asset('css/index.css') }}">
@endsection

@section('js')
    <script src="{{ asset('js/index.js') }}" defer></script>
@endsection
