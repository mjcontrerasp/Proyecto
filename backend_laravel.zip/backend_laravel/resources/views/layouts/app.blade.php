<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'SocialFood')</title>

    {{-- CSS global (Bootstrap si usas) --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    {{-- CSS específico de cada vista --}}
    @yield('css')
</head>
<body>

    {{-- Contenido de cada vista --}}
    @yield('content')

    {{-- JS global --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    {{-- JS específico de cada vista --}}
    @yield('js')
</body>
</html>
